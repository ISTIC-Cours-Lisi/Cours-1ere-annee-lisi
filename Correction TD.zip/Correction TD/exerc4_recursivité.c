#include<stdio.h>
#include <stdlib.h>
int pair (char [], int, char) ;
int main()
{
    char ch [20], car;
    int test;
    printf("saisie la chaîne : ");
    gets(ch);//scanf("%s", ch);
    printf("\n saisir caractère : ");
    scanf("%c", & car);
    test = pair (ch, 0, car) ;
    if (test) 
        printf("\n est pair");
    else
        printf("\n n'est pas pair ");
    return 0;
}
int pair (char ch[], int i , char c) {
int res;
if(ch[i] == '\0' ) 
    res=1;
else {
   if (ch[i]== c)
        res = ! pair(ch, i+1,c);
   else
        res = pair(ch, i+1, c) ;
        
     } 
return res;
} 