#include <stdio.h>
#include <stdlib.h>
void oddonly(int *,int **, int, int *, int );
void afficher (int *, int);
void remplirdyn( int *, int);
int main()
{
    int n, m,pos=0, *t1, *t2;
    do{
        printf("donner n :");
        scanf("%d",&n);
    }while(n<1);
    t1=malloc(n*sizeof(int));
    remplirdyn(t1,n);
    m=0;
    oddonly(t1,&t2, n, &m, pos);
    afficher(t1, n);
    printf("\n");
    afficher(t2, m);
    return 0;
}

void oddonly(int *t1,int **t2, int n , int *m, int pos) {
   int *P;
    if (n ==0){
        *t2=malloc(*m*sizeof(int));
    }
    else {
        if ((*t1)%2!=0) {
            *m=(*m)+1;
            oddonly(t1+1, t2,n-1,m, pos+1);
            P=(*t2)+pos;
            *P=*t1;
        }
        else
          oddonly(t1+1, t2,n-1,m, pos);
    }
}
void remplirdyn( int *t, int n) {
    int *p;
    for (p=t;p<t+n;p++){
        printf("\nsaisir un entier : ");
        scanf("%d",p);
    }
}
void afficher (int *T, int n) {
    int *i;
    printf("Le tableau contient : \n ");
    for(i=T;i<T+n;i++)
        printf ("%d\t",*i);
}
